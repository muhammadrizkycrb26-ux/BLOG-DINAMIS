<?php
require_once 'config/database.php';

$slug = $_GET['slug'] ?? '';
if (!$slug) {
    header('Location: index.php');
    exit();
}

$stmt = $pdo->prepare("SELECT a.*, u.username as author, c.name as category_name, c.slug as category_slug FROM articles a LEFT JOIN users u ON a.author_id = u.id LEFT JOIN categories c ON a.category_id = c.id WHERE a.slug = ? AND a.status = 'published'");
$stmt->execute([$slug]);
$article = $stmt->fetch();

if (!$article) {
    die('Artikel tidak ditemukan');
}

$stmt_tag = $pdo->prepare("SELECT t.* FROM tags t JOIN article_tags at ON t.id = at.tag_id WHERE at.article_id = ?");
$stmt_tag->execute([$article['id']]);
$tags = $stmt_tag->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_comment'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $content = $_POST['content'];
    $stmt = $pdo->prepare("INSERT INTO comments (article_id, author_name, author_email, content, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->execute([$article['id'], $name, $email, $content]);
    header("Location: article.php?slug=$slug");
    exit();
}

$stmt_com = $pdo->prepare("SELECT * FROM comments WHERE article_id = ? ORDER BY created_at DESC");
$stmt_com->execute([$article['id']]);
$comments = $stmt_com->fetchAll();
?>
<!DOCTYPE html>
<html>

<head>
    <title><?= htmlspecialchars($article['title']) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="front-container">
        <header> <!-- sama seperti index --> </header>
        <main>
            <article>
                <h1><?= htmlspecialchars($article['title']) ?></h1>
                <div class="post-meta">
                    Ditulis oleh <?= htmlspecialchars($article['author']) ?> | Kategori: <a
                        href="category.php?slug=<?= $article['category_slug'] ?>"><?= htmlspecialchars($article['category_name']) ?></a>
                    | <?= $article['created_at'] ?>
                </div>
                <div class="post-tags">
                    Tags:
                    <?php foreach ($tags as $tag): ?>
                        <a href="tag.php?slug=<?= $tag['slug'] ?>"><?= htmlspecialchars($tag['name']) ?></a>
                    <?php endforeach; ?>
                </div>
                <div class="post-content">
                    <?= nl2br(htmlspecialchars($article['content'])) ?>
                </div>
            </article>

            <section class="comments">
                <h3>Komentar (<?= count($comments) ?>)</h3>
                <?php foreach ($comments as $comment): ?>
                    <div class="comment">
                        <strong><?= htmlspecialchars($comment['author_name']) ?></strong>
                        <small><?= $comment['created_at'] ?></small>
                        <p><?= nl2br(htmlspecialchars($comment['content'])) ?></p>
                    </div>
                <?php endforeach; ?>

                <h4>Tinggalkan Komentar</h4>
                <form method="POST">
                    <input type="text" name="name" placeholder="Nama" required>
                    <input type="email" name="email" placeholder="Email" required>
                    <textarea name="content" rows="5" placeholder="Komentar Anda" required></textarea>
                    <button type="submit" name="submit_comment">Kirim Komentar</button>
                </form>
            </section>
        </main>
        <aside> <!-- sama seperti index --> </aside>
    </div>
</body>

</html>