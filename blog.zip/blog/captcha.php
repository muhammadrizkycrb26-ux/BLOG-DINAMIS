<?php
session_start();

// Generate random string (5 karakter)
$random_string = substr(str_shuffle('ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'), 0, 5);
$_SESSION['captcha_text'] = $random_string;

// Buat gambar
$image = imagecreate(120, 40);
$bg_color = imagecolorallocate($image, 255, 255, 255);
$text_color = imagecolorallocate($image, 0, 0, 0);
$line_color = imagecolorallocate($image, 64, 64, 64);

// Tambahkan garis acak
for ($i = 0; $i < 5; $i++) {
    imageline($image, rand(0, 120), rand(0, 40), rand(0, 120), rand(0, 40), $line_color);
}

// Tulis teks
imagestring($image, 5, 20, 12, $random_string, $text_color);

header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
?>