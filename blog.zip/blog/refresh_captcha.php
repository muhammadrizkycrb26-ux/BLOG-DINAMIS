<?php
session_start();
$characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ123456789';
$captcha_text = '';
for ($i = 0; $i < 4; $i++) {
    $captcha_text .= $characters[rand(0, strlen($characters) - 1)];
}
$_SESSION['captcha_text'] = $captcha_text;
header('Content-Type: application/json');
echo json_encode(['captcha' => $captcha_text]);
?>