<?php
require_once 'config/database.php';

$page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
$limit = 6;
$offset = ($page - 1) * $limit;

$stmt = $pdo->prepare("SELECT a.*, u.username as author, c.name as category_name 
                       FROM articles a 
                       LEFT JOIN users u ON a.author_id = u.id 
                       LEFT JOIN categories c ON a.category_id = c.id 
                       WHERE a.status = 'published' 
                       ORDER BY a.created_at DESC 
                       LIMIT ? OFFSET ?");
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();
$articles = $stmt->fetchAll();

$total = $pdo->query("SELECT COUNT(*) FROM articles WHERE status='published'")->fetchColumn();
$total_pages = ceil($total / $limit);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Futuristik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            transition: background 0.3s;
        }

        body.dark-mode {
            background: linear-gradient(135deg, #1e1e2f 0%, #0f0f1a 100%);
            color: #e0e0e0;
        }

        .navbar-glass {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
        }

        body.dark-mode .navbar-glass {
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(12px);
        }

        .card-blog {
            border: none;
            border-radius: 28px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(8px);
            transition: all 0.4s cubic-bezier(0.2, 0.9, 0.4, 1.1);
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }

        .card-blog:hover {
            transform: translateY(-12px) scale(1.02);
            box-shadow: 0 25px 45px rgba(0, 0, 0, 0.2);
            background: white;
        }

        body.dark-mode .card-blog {
            background: rgba(30, 30, 47, 0.9);
            color: #f0f0f0;
        }

        body.dark-mode .card-blog:hover {
            background: #2d2d44;
        }

        .badge-category {
            background: linear-gradient(90deg, #6366f1, #8b5cf6);
            border-radius: 30px;
            padding: 6px 16px;
            font-weight: 500;
        }

        .btn-outline-futuristic {
            border: 2px solid #6366f1;
            border-radius: 40px;
            padding: 8px 24px;
            font-weight: 600;
            transition: all 0.3s;
            background: transparent;
        }

        .btn-outline-futuristic:hover {
            background: #6366f1;
            color: white;
            transform: scale(1.05);
        }

        .pagination .page-link {
            border-radius: 30px;
            margin: 0 5px;
            background: rgba(255, 255, 255, 0.8);
            border: none;
            font-weight: 500;
        }

        body.dark-mode .pagination .page-link {
            background: #2d2d44;
            color: white;
        }

        .animate-fade-up {
            animation: fadeUp 0.6s ease forwards;
            opacity: 0;
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-glass fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold fs-3" href="index.php">
                <i class="fas fa-blog me-2" style="color: #6366f1;"></i>FuturBlog
            </a>
            <div class="ms-auto">
                <button id="darkModeToggle" class="btn btn-outline-light rounded-pill">
                    <i class="fas fa-moon"></i> Mode
                </button>
                <a href="login.php" class="btn btn-outline-futuristic ms-2">Login</a>
            </div>
        </div>
    </nav>

    <!-- Hero -->
    <div class="container pt-5 mt-5">
        <div class="text-center py-5 animate-fade-up" style="animation-delay: 0.1s;">
            <h1 class="display-4 fw-bold bg-gradient-to-r"
                style="background: linear-gradient(120deg, #6366f1, #a855f7); -webkit-background-clip: text; background-clip: text; color: transparent;">
                Eksplorasi Artikel</h1>
            <p class="lead text-muted">Temukan wawasan menarik dari berbagai topik</p>
        </div>

        <!-- Grid Artikel -->
        <div class="row g-4">
            <?php foreach ($articles as $article): ?>
                <div class="col-md-6 col-lg-4 animate-fade-up" style="animation-delay: <?= rand(1, 5) * 0.05 ?>s;">
                    <div class="card-blog p-3">
                        <div class="position-relative">
                            <div class="badge-category position-absolute top-0 start-0 m-3 text-white">
                                <i class="fas fa-folder-open me-1"></i> <?= htmlspecialchars($article['category_name']) ?>
                            </div>
                            <div class="card-body mt-3">
                                <h5 class="fw-semibold mt-2"><?= htmlspecialchars($article['title']) ?></h5>
                                <p class="text-muted small">
                                    <i class="fas fa-user me-1"></i> <?= htmlspecialchars($article['author']) ?>
                                    <i class="fas fa-calendar-alt ms-2 me-1"></i>
                                    <?= date('d M Y', strtotime($article['created_at'])) ?>
                                </p>
                                <p class="card-text">
                                    <?= htmlspecialchars(substr(strip_tags($article['content']), 0, 100)) ?>...
                                </p>
                                <a href="article.php?slug=<?= $article['slug'] ?>"
                                    class="btn btn-outline-futuristic w-100">Baca Selengkapnya <i
                                        class="fas fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="d-flex justify-content-center mt-5">
                <nav>
                    <ul class="pagination">
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
            </div>
        <?php endif; ?>
    </div>

    <script>
        const toggle = document.getElementById('darkModeToggle');
        toggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            const icon = toggle.querySelector('i');
            if (document.body.classList.contains('dark-mode')) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
                toggle.innerHTML = '<i class="fas fa-sun"></i> Light';
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
                toggle.innerHTML = '<i class="fas fa-moon"></i> Dark';
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>