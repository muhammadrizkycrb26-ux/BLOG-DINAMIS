<?php
session_start();
require_once 'config/database.php';

if (isset($_SESSION['user_id'])) {
    header('Location: admin/dashboard.php');
    exit();
}

// Generate CAPTCHA teks (4 karakter)
if (!isset($_SESSION['captcha_text']) || isset($_GET['refresh'])) {
    $characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ123456789';
    $captcha_text = '';
    for ($i = 0; $i < 4; $i++) {
        $captcha_text .= $characters[rand(0, strlen($characters) - 1)];
    }
    $_SESSION['captcha_text'] = $captcha_text;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_captcha = strtoupper(trim($_POST['captcha']));
    if ($user_captcha !== $_SESSION['captcha_text']) {
        $error = 'Kode CAPTCHA salah!';
        unset($_SESSION['captcha_text']);
    } else {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            unset($_SESSION['captcha_text']);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            header('Location: admin/dashboard.php');
            exit();
        } else {
            $error = 'Username atau password salah!';
            unset($_SESSION['captcha_text']);
        }
    }
    if ($error) {
        header('Location: login.php?error=' . urlencode($error));
        exit();
    }
}
if (isset($_GET['error'])) {
    $error = htmlspecialchars($_GET['error']);
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Blog Admin</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 (opsional) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 25px 45px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(10px);
            transition: transform 0.3s ease;
            max-width: 450px;
            width: 100%;
            border: none;
        }

        .login-card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            background: transparent;
            border-bottom: none;
            text-align: center;
            padding: 2rem 2rem 0 2rem;
        }

        .card-header h2 {
            font-weight: 700;
            color: #333;
        }

        .card-header p {
            color: #6c757d;
            font-size: 0.9rem;
        }

        .card-body {
            padding: 2rem;
        }

        .form-control,
        .input-group-text {
            border-radius: 12px;
            border: 1px solid #e0e0e0;
            padding: 12px 15px;
            transition: all 0.2s;
        }

        .form-control:focus {
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.25);
            border-color: #667eea;
        }

        .btn-login {
            background: linear-gradient(45deg, #667eea, #764ba2);
            border: none;
            border-radius: 12px;
            padding: 12px;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s;
        }

        .btn-login:hover {
            transform: scale(1.02);
            background: linear-gradient(45deg, #5a67d8, #6b46a0);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .captcha-box {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .captcha-code {
            font-family: 'Courier New', monospace;
            font-size: 1.8rem;
            font-weight: bold;
            letter-spacing: 8px;
            color: #2c3e66;
            background: #e9ecef;
            padding: 5px 15px;
            border-radius: 10px;
        }

        .refresh-captcha {
            background: none;
            border: none;
            color: #667eea;
            font-size: 1.2rem;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .refresh-captcha:hover {
            transform: rotate(15deg);
            color: #764ba2;
        }

        .alert-custom {
            border-radius: 12px;
            background: #f8d7da;
            border-left: 5px solid #dc3545;
        }

        footer {
            text-align: center;
            margin-top: 1.5rem;
            color: #aaa;
            font-size: 0.8rem;
        }

        @media (max-width: 480px) {
            .card-body {
                padding: 1.5rem;
            }

            .captcha-code {
                font-size: 1.4rem;
                letter-spacing: 5px;
            }
        }
    </style>
</head>

<body>
    <div class="login-card card">
        <div class="card-header">
            <h2><i class="fas fa-blog me-2"></i> Blog Admin</h2>
            <p>Silakan masuk dengan akun Anda</p>
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div class="alert alert-custom alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i> <?= $error ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-user me-1"></i> Username</label>
                    <input type="text" name="username" class="form-control" placeholder="Masukkan username" required
                        autofocus>
                </div>
                <div class="mb-4">
                    <label class="form-label"><i class="fas fa-lock me-1"></i> Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Masukkan password"
                        required>
                </div>

                <!-- CAPTCHA Area -->
                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-shield-alt me-1"></i> Kode Keamanan</label>
                    <div class="captcha-box">
                        <span class="captcha-code" id="captchaText"><?= $_SESSION['captcha_text'] ?></span>
                        <button type="button" class="refresh-captcha" id="refreshCaptcha" title="Refresh CAPTCHA">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </div>
                    <input type="text" name="captcha" class="form-control" placeholder="Masukkan kode di atas"
                        maxlength="4" required>
                    <div class="form-text">Kode bersifat case-sensitive (huruf besar semua)</div>
                </div>

                <button type="submit" class="btn btn-login w-100 text-white">
                    <i class="fas fa-sign-in-alt me-2"></i> Masuk
                </button>
            </form>

            <div class="mt-4 text-center small text-muted">
                <i class="fas fa-info-circle"></i> Demo: admin/password | author/password
            </div>
        </div>
        <footer>
            &copy; 2025 Blog Dinamis
        </footer>
    </div>

    <!-- Bootstrap JS + Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- JavaScript untuk refresh CAPTCHA tanpa reload halaman -->
    <script>
        document.getElementById('refreshCaptcha').addEventListener('click', function () {
            fetch('refresh_captcha.php')
                .then(response => response.json())
                .then(data => {
                    if (data.captcha) {
                        document.getElementById('captchaText').innerText = data.captcha;
                    }
                })
                .catch(err => {
                    // fallback: reload halaman dengan parameter refresh
                    window.location.href = '?refresh=1';
                });
        });
    </script>
</body>

</html>