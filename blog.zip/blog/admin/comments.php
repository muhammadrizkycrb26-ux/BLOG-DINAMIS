<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Hapus komentar
if (isset($_GET['delete'])) {
    $comment_id = $_GET['delete'];
    if ($role == 'admin') {
        $stmt = $pdo->prepare("DELETE FROM comments WHERE id = ?");
        $stmt->execute([$comment_id]);
    } else {
        // Author hanya bisa hapus komentar pada artikelnya sendiri
        $stmt = $pdo->prepare("DELETE comments FROM comments 
                               JOIN articles ON comments.article_id = articles.id 
                               WHERE comments.id = ? AND articles.author_id = ?");
        $stmt->execute([$comment_id, $user_id]);
    }
    header('Location: comments.php');
    exit();
}

// Ambil data komentar
if ($role == 'admin') {
    $stmt = $pdo->query("SELECT c.*, a.title as article_title, a.author_id 
                         FROM comments c 
                         LEFT JOIN articles a ON c.article_id = a.id 
                         ORDER BY c.created_at DESC");
} else {
    $stmt = $pdo->prepare("SELECT c.*, a.title as article_title 
                           FROM comments c 
                           LEFT JOIN articles a ON c.article_id = a.id 
                           WHERE a.author_id = ? 
                           ORDER BY c.created_at DESC");
    $stmt->execute([$user_id]);
}
$comments = $stmt->fetchAll();

// Hitung total komentar
$total_comments = count($comments);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Komentar | BlogCMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: #f0f4f8;
            transition: background 0.3s;
        }

        body.dark-mode {
            background: #121212;
            color: #e0e0e0;
        }

        .sidebar {
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
        }

        .sidebar .nav-link {
            color: #cbd5e1;
            border-radius: 12px;
            margin: 5px 10px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background: rgba(99, 102, 241, 0.2);
            color: white;
        }

        .card-glass {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(8px);
            border-radius: 28px;
            border: none;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
        }

        body.dark-mode .card-glass {
            background: rgba(30, 30, 47, 0.9);
        }

        .btn-gradient {
            background: linear-gradient(90deg, #6366f1, #8b5cf6);
            border: none;
            color: white;
            border-radius: 40px;
            padding: 8px 20px;
        }

        .table-custom th {
            background: #f8fafc;
            border-bottom: 2px solid #e2e8f0;
        }

        body.dark-mode .table-custom th {
            background: #2d2d44;
            border-color: #444;
        }

        .comment-preview {
            max-width: 300px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .badge-article {
            background: #e2e8f0;
            color: #1e293b;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 0.75rem;
        }

        body.dark-mode .badge-article {
            background: #2d2d44;
            color: #ccc;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-3">
                <div class="text-center mb-4">
                    <i class="fas fa-blog fa-3x text-white"></i>
                    <h4 class="text-white mt-2">BlogCMS</h4>
                    <span class="badge bg-light text-dark"><?= ucfirst($role) ?></span>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i
                                class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="articles.php"><i class="fas fa-newspaper me-2"></i>
                            Artikel</a></li>
                    <?php if ($role == 'admin'): ?>
                        <li class="nav-item"><a class="nav-link" href="categories.php"><i class="fas fa-tags me-2"></i>
                                Kategori</a></li>
                        <li class="nav-item"><a class="nav-link" href="tags.php"><i class="fas fa-hashtag me-2"></i> Tag</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item"><a class="nav-link active" href="comments.php"><i
                                class="fas fa-comments me-2"></i> Komentar</a></li>
                    <li class="nav-item mt-4"><a class="nav-link" href="../logout.php"><i
                                class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                </ul>
                <div class="position-absolute bottom-0 mb-4">
                    <button id="darkModeToggle" class="btn btn-outline-light rounded-pill w-100">
                        <i class="fas fa-moon"></i> Dark Mode
                    </button>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="fw-bold"><i class="fas fa-comments me-2 text-primary"></i> Manajemen Komentar</h2>
                    <div class="text-muted">Total: <?= $total_comments ?> komentar</div>
                </div>

                <div class="card-glass p-4">
                    <div class="table-responsive">
                        <table class="table table-custom align-middle">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Artikel</th>
                                    <th>Nama</th>
                                    <th>Email</th>
                                    <th>Komentar</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($comments) > 0): ?>
                                    <?php foreach ($comments as $comment): ?>
                                        <tr>
                                            <td><?= $comment['id'] ?></td>
                                            <td>
                                                <span class="badge-article">
                                                    <i class="fas fa-file-alt me-1"></i>
                                                    <?= htmlspecialchars(substr($comment['article_title'] ?? 'Tanpa Judul', 0, 30)) ?>
                                                </span>
                                            </td>
                                            <td><strong><?= htmlspecialchars($comment['author_name']) ?></strong></td>
                                            <td><?= htmlspecialchars($comment['author_email']) ?></td>
                                            <td class="comment-preview">
                                                <?= nl2br(htmlspecialchars(substr($comment['content'], 0, 80))) ?>...</td>
                                            <td><?= date('d/m/Y H:i', strtotime($comment['created_at'])) ?></td>
                                            <td>
                                                <a href="?delete=<?= $comment['id'] ?>"
                                                    class="btn btn-sm btn-outline-danger rounded-pill"
                                                    onclick="return confirm('Yakin hapus komentar ini?')">
                                                    <i class="fas fa-trash-alt"></i> Hapus
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-5">
                                            <i class="fas fa-comment-slash fa-3x text-muted mb-2"></i>
                                            <p class="mb-0">Belum ada komentar.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const toggle = document.getElementById('darkModeToggle');
        toggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            const icon = toggle.querySelector('i');
            if (document.body.classList.contains('dark-mode')) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
                toggle.innerHTML = '<i class="fas fa-sun"></i> Light Mode';
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
                toggle.innerHTML = '<i class="fas fa-moon"></i> Dark Mode';
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>