<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];
$is_edit = false;
$article = [
    'id' => '',
    'title' => '',
    'content' => '',
    'category_id' => '',
    'status' => 'published',
    'featured_image' => ''
];
$selected_tags = [];

// Jika mode edit
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    if ($role == 'admin') {
        $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ?");
        $stmt->execute([$id]);
    } else {
        $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ? AND author_id = ?");
        $stmt->execute([$id, $user_id]);
    }
    $article = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($article) {
        $is_edit = true;
        $stmt_tag = $pdo->prepare("SELECT tag_id FROM article_tags WHERE article_id = ?");
        $stmt_tag->execute([$id]);
        $selected_tags = $stmt_tag->fetchAll(PDO::FETCH_COLUMN);
    } else {
        header('Location: articles.php');
        exit();
    }
}

// Ambil data kategori dan tag untuk form
$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$tags = $pdo->query("SELECT * FROM tags ORDER BY name")->fetchAll();

// Proses submit form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $content = $_POST['content'];
    $category_id = $_POST['category_id'];
    $status = $_POST['status'];
    $tag_ids = isset($_POST['tags']) ? $_POST['tags'] : [];

    // Generate slug dari title
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));

    // Upload featured image jika ada
    $featured_image = $article['featured_image'] ?? '';
    if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $filename = $_FILES['featured_image']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            $new_filename = time() . '_' . uniqid() . '.' . $ext;
            $upload_dir = '../uploads/';
            if (!is_dir($upload_dir))
                mkdir($upload_dir, 0777, true);
            if (move_uploaded_file($_FILES['featured_image']['tmp_name'], $upload_dir . $new_filename)) {
                $featured_image = 'uploads/' . $new_filename;
            }
        }
    }

    if ($is_edit) {
        $id = $_GET['edit'];
        if ($role == 'admin') {
            $stmt = $pdo->prepare("UPDATE articles SET title=?, slug=?, content=?, category_id=?, status=?, featured_image=?, updated_at=NOW() WHERE id=?");
            $stmt->execute([$title, $slug, $content, $category_id, $status, $featured_image, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE articles SET title=?, slug=?, content=?, category_id=?, status=?, featured_image=?, updated_at=NOW() WHERE id=? AND author_id=?");
            $stmt->execute([$title, $slug, $content, $category_id, $status, $featured_image, $id, $user_id]);
        }
        // Update tag
        $stmt_del = $pdo->prepare("DELETE FROM article_tags WHERE article_id = ?");
        $stmt_del->execute([$id]);
        foreach ($tag_ids as $tag_id) {
            $stmt_ins = $pdo->prepare("INSERT INTO article_tags (article_id, tag_id) VALUES (?, ?)");
            $stmt_ins->execute([$id, $tag_id]);
        }
    } else {
        $stmt = $pdo->prepare("INSERT INTO articles (title, slug, content, category_id, author_id, status, featured_image, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
        $stmt->execute([$title, $slug, $content, $category_id, $user_id, $status, $featured_image]);
        $article_id = $pdo->lastInsertId();
        foreach ($tag_ids as $tag_id) {
            $stmt_ins = $pdo->prepare("INSERT INTO article_tags (article_id, tag_id) VALUES (?, ?)");
            $stmt_ins->execute([$article_id, $tag_id]);
        }
    }
    header('Location: articles.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $is_edit ? 'Edit Artikel' : 'Tambah Artikel' ?> | BlogCMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: #f0f4f8;
            transition: background 0.3s;
        }

        body.dark-mode {
            background: #121212;
            color: #e0e0e0;
        }

        .sidebar {
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
        }

        .sidebar .nav-link {
            color: #cbd5e1;
            border-radius: 12px;
            margin: 5px 10px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background: rgba(99, 102, 241, 0.2);
            color: white;
        }

        .card-glass {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(8px);
            border-radius: 28px;
            border: none;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
        }

        body.dark-mode .card-glass {
            background: rgba(30, 30, 47, 0.9);
        }

        .btn-gradient {
            background: linear-gradient(90deg, #6366f1, #8b5cf6);
            border: none;
            color: white;
            border-radius: 40px;
            padding: 10px 24px;
            transition: all 0.3s;
        }

        .btn-gradient:hover {
            transform: scale(1.02);
            box-shadow: 0 5px 15px rgba(99, 102, 241, 0.4);
        }

        .form-control,
        .form-select {
            border-radius: 20px;
            border: 2px solid #e2e8f0;
            padding: 10px 16px;
            transition: all 0.3s;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
        }

        body.dark-mode .form-control,
        body.dark-mode .form-select {
            background: #2d2d44;
            border-color: #444;
            color: #e0e0e0;
        }

        .tag-checkbox {
            display: inline-flex;
            align-items: center;
            background: #f1f5f9;
            border-radius: 40px;
            padding: 5px 15px;
            margin: 5px;
            cursor: pointer;
            transition: all 0.2s;
        }

        .tag-checkbox:hover {
            background: #e2e8f0;
        }

        body.dark-mode .tag-checkbox {
            background: #2d2d44;
        }

        .tag-checkbox input {
            margin-right: 8px;
        }

        .image-preview {
            max-width: 200px;
            margin-top: 10px;
            border-radius: 16px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-3">
                <div class="text-center mb-4">
                    <i class="fas fa-blog fa-3x text-white"></i>
                    <h4 class="text-white mt-2">BlogCMS</h4>
                    <span class="badge bg-light text-dark"><?= ucfirst($role) ?></span>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i
                                class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="articles.php"><i
                                class="fas fa-newspaper me-2"></i> Artikel</a></li>
                    <?php if ($role == 'admin'): ?>
                        <li class="nav-item"><a class="nav-link" href="categories.php"><i class="fas fa-tags me-2"></i>
                                Kategori</a></li>
                        <li class="nav-item"><a class="nav-link" href="tags.php"><i class="fas fa-hashtag me-2"></i> Tag</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item"><a class="nav-link" href="comments.php"><i class="fas fa-comments me-2"></i>
                            Komentar</a></li>
                    <li class="nav-item mt-4"><a class="nav-link" href="../logout.php"><i
                                class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                </ul>
                <div class="position-absolute bottom-0 mb-4">
                    <button id="darkModeToggle" class="btn btn-outline-light rounded-pill w-100">
                        <i class="fas fa-moon"></i> Dark Mode
                    </button>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="fw-bold"><i class="fas fa-edit me-2 text-primary"></i>
                        <?= $is_edit ? 'Edit Artikel' : 'Tulis Artikel Baru' ?></h2>
                    <a href="articles.php" class="btn btn-outline-secondary rounded-pill"><i
                            class="fas fa-arrow-left me-2"></i> Kembali</a>
                </div>

                <div class="card-glass p-4">
                    <form method="POST" enctype="multipart/form-data">
                        <!-- Judul -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold"><i class="fas fa-heading me-2"></i> Judul
                                Artikel</label>
                            <input type="text" name="title" id="title" class="form-control"
                                value="<?= htmlspecialchars($article['title']) ?>" required
                                placeholder="Masukkan judul yang menarik...">
                            <small class="text-muted mt-1">Slug akan dibuat otomatis: <span id="slugPreview"
                                    class="text-primary"><?= $is_edit ? $article['slug'] : '' ?></span></small>
                        </div>

                        <!-- Featured Image -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold"><i class="fas fa-image me-2"></i> Gambar Sampul
                                (Opsional)</label>
                            <input type="file" name="featured_image" id="featured_image" class="form-control"
                                accept="image/*">
                            <?php if ($is_edit && $article['featured_image']): ?>
                                <div class="mt-2">
                                    <img src="../<?= $article['featured_image'] ?>" class="image-preview" alt="Preview">
                                    <p class="small text-muted mt-1">Gambar saat ini. Upload baru untuk mengganti.</p>
                                </div>
                            <?php endif; ?>
                            <div id="previewContainer" class="mt-2" style="display: none;">
                                <img id="imagePreview" class="image-preview" alt="Preview">
                            </div>
                        </div>

                        <div class="row">
                            <!-- Kategori -->
                            <div class="col-md-6 mb-4">
                                <label class="form-label fw-semibold"><i class="fas fa-folder me-2"></i>
                                    Kategori</label>
                                <select name="category_id" class="form-select" required>
                                    <option value="">Pilih Kategori</option>
                                    <?php foreach ($categories as $cat): ?>
                                        <option value="<?= $cat['id'] ?>" <?= ($article['category_id'] == $cat['id']) ? 'selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <!-- Status -->
                            <div class="col-md-6 mb-4">
                                <label class="form-label fw-semibold"><i class="fas fa-globe me-2"></i> Status</label>
                                <select name="status" class="form-select">
                                    <option value="published" <?= ($article['status'] == 'published') ? 'selected' : '' ?>>
                                        Published (Langsung terbit)</option>
                                    <option value="draft" <?= ($article['status'] == 'draft') ? 'selected' : '' ?>>Draft
                                        (Simpan draf)</option>
                                </select>
                            </div>
                        </div>

                        <!-- Tag -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold"><i class="fas fa-hashtag me-2"></i> Tag</label>
                            <div class="d-flex flex-wrap">
                                <?php foreach ($tags as $tag): ?>
                                    <label class="tag-checkbox">
                                        <input type="checkbox" name="tags[]" value="<?= $tag['id'] ?>"
                                            <?= in_array($tag['id'], $selected_tags) ? 'checked' : '' ?>>
                                        <?= htmlspecialchars($tag['name']) ?>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                            <small class="text-muted">Pilih satu atau lebih tag yang relevan.</small>
                        </div>

                        <!-- Konten -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold"><i class="fas fa-paragraph me-2"></i> Konten</label>
                            <textarea name="content" rows="15" class="form-control" required
                                placeholder="Tulis konten artikel di sini..."><?= htmlspecialchars($article['content']) ?></textarea>
                        </div>

                        <!-- Tombol Submit -->
                        <div class="d-flex justify-content-end gap-3">
                            <button type="reset" class="btn btn-outline-secondary rounded-pill px-4">Reset</button>
                            <button type="submit"
                                class="btn btn-gradient px-5"><?= $is_edit ? 'Update Artikel' : 'Publish Artikel' ?> <i
                                    class="fas fa-paper-plane ms-2"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Slug otomatis dari judul
        const titleInput = document.getElementById('title');
        const slugPreview = document.getElementById('slugPreview');
        function generateSlug(text) {
            return text.toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .trim();
        }
        titleInput.addEventListener('input', function () {
            let slug = generateSlug(this.value);
            slugPreview.textContent = slug;
        });

        // Preview gambar sebelum upload
        const fileInput = document.getElementById('featured_image');
        const previewContainer = document.getElementById('previewContainer');
        const imagePreview = document.getElementById('imagePreview');
        fileInput.addEventListener('change', function (event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    imagePreview.src = e.target.result;
                    previewContainer.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                previewContainer.style.display = 'none';
            }
        });

        // Dark mode toggle
        const toggle = document.getElementById('darkModeToggle');
        toggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            const icon = toggle.querySelector('i');
            if (document.body.classList.contains('dark-mode')) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
                toggle.innerHTML = '<i class="fas fa-sun"></i> Light Mode';
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
                toggle.innerHTML = '<i class="fas fa-moon"></i> Dark Mode';
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>