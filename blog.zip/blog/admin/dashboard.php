<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$role = $_SESSION['role'];
$username = $_SESSION['username'];

// Statistik
$total_articles = $pdo->query("SELECT COUNT(*) FROM articles")->fetchColumn();
$total_categories = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$total_tags = $pdo->query("SELECT COUNT(*) FROM tags")->fetchColumn();
$total_comments = $pdo->query("SELECT COUNT(*) FROM comments")->fetchColumn();

// Data untuk chart (6 bulan terakhir)
$months = [];
$article_counts = [];
$comment_counts = [];
for ($i = 5; $i >= 0; $i--) {
    $months[] = date('M', strtotime("-$i months"));
    $start = date('Y-m-01', strtotime("-$i months"));
    $end = date('Y-m-t', strtotime("-$i months"));
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM articles WHERE created_at BETWEEN ? AND ?");
    $stmt->execute([$start, $end]);
    $article_counts[] = $stmt->fetchColumn();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM comments WHERE created_at BETWEEN ? AND ?");
    $stmt->execute([$start, $end]);
    $comment_counts[] = $stmt->fetchColumn();
}

// Artikel terbaru
$recent_articles = $pdo->query("SELECT a.title, a.created_at, u.username as author, a.status FROM articles a JOIN users u ON a.author_id = u.id ORDER BY a.created_at DESC LIMIT 5")->fetchAll();

// Komentar terbaru
$recent_comments = $pdo->query("SELECT c.author_name, c.content, a.title as article_title, c.created_at FROM comments c JOIN articles a ON c.article_id = a.id ORDER BY c.created_at DESC LIMIT 5")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Futuristik | BlogCMS</title>
    <!-- Bootstrap 5 + Icons + Fonts -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: #f0f4f8;
            transition: background 0.3s, color 0.3s;
        }

        /* Dark Mode */
        body.dark-mode {
            background: #121212;
            color: #e0e0e0;
        }

        body.dark-mode .card,
        body.dark-mode .chart-container,
        body.dark-mode .table-custom,
        body.dark-mode .sidebar {
            background: #1e1e2f;
            color: #e0e0e0;
            border-color: #2d2d44;
        }

        body.dark-mode .table-custom th {
            background: #2d2d44;
            color: #fff;
        }

        body.dark-mode .table-custom td {
            color: #ccc;
        }

        body.dark-mode .text-muted {
            color: #aaa !important;
        }

        /* Sidebar Futuristik */
        .sidebar {
            background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
            min-height: 100vh;
            box-shadow: 8px 0 20px rgba(0, 0, 0, 0.2);
            transition: all 0.3s;
            border-right: 1px solid rgba(255, 255, 255, 0.05);
        }

        .sidebar .nav-link {
            color: #cbd5e1;
            border-radius: 12px;
            margin: 6px 12px;
            padding: 12px 16px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-weight: 500;
        }

        .sidebar .nav-link i {
            width: 28px;
            font-size: 1.2rem;
        }

        .sidebar .nav-link:hover {
            background: rgba(99, 102, 241, 0.2);
            color: white;
            transform: translateX(8px);
            backdrop-filter: blur(4px);
        }

        .sidebar .nav-link.active {
            background: linear-gradient(90deg, #6366f1, #8b5cf6);
            color: white;
            box-shadow: 0 5px 15px rgba(99, 102, 241, 0.3);
        }

        /* Card Statistik */
        .stat-card {
            border: none;
            border-radius: 24px;
            background: white;
            transition: all 0.3s;
            overflow: hidden;
            position: relative;
            backdrop-filter: blur(10px);
        }

        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 35px -12px rgba(0, 0, 0, 0.2);
        }

        .stat-icon {
            position: absolute;
            right: 20px;
            bottom: 20px;
            font-size: 3.5rem;
            opacity: 0.15;
        }

        .stat-number {
            font-size: 2.2rem;
            font-weight: 800;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(120deg, #1e293b, #0f172a);
            border-radius: 28px;
            padding: 28px;
            color: white;
            position: relative;
            overflow: hidden;
            box-shadow: 0 15px 30px -10px rgba(0, 0, 0, 0.2);
        }

        .welcome-banner::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(139, 92, 246, 0.3), transparent);
            border-radius: 50%;
        }

        .avatar-large {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            font-weight: bold;
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.4);
        }

        /* Chart Container */
        .chart-container {
            background: white;
            border-radius: 24px;
            padding: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
            transition: all 0.3s;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        /* Table */
        .table-custom {
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .table-custom th {
            background: #f8fafc;
            border-bottom: 2px solid #e2e8f0;
            font-weight: 600;
        }

        /* Dark Mode Toggle */
        .dark-mode-toggle {
            cursor: pointer;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 30px;
            padding: 8px 16px;
            transition: all 0.3s;
        }

        .dark-mode-toggle:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        /* Animasi fade-in */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-fade {
            animation: fadeInUp 0.6s ease forwards;
        }
    </style>
</head>

<body>
    <div class="container-fluid p-0">
        <div class="row g-0">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-3">
                <div class="text-center mb-4 pt-3">
                    <i class="fas fa-blog fa-3x text-white"
                        style="filter: drop-shadow(0 5px 10px rgba(0,0,0,0.3));"></i>
                    <h4 class="text-white mt-2 fw-bold">BlogCMS</h4>
                    <span class="badge bg-gradient-to-r from-indigo-500 to-purple-600 mt-1 px-3 py-1 rounded-pill"
                        style="background: linear-gradient(90deg,#6366f1,#8b5cf6);"><?= ucfirst($role) ?></span>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link active" href="dashboard.php"><i
                                class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="articles.php"><i class="fas fa-newspaper me-2"></i>
                            Artikel</a></li>
                    <?php if ($role == 'admin'): ?>
                        <li class="nav-item"><a class="nav-link" href="categories.php"><i class="fas fa-tags me-2"></i>
                                Kategori</a></li>
                        <li class="nav-item"><a class="nav-link" href="tags.php"><i class="fas fa-hashtag me-2"></i> Tag</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item"><a class="nav-link" href="comments.php"><i class="fas fa-comments me-2"></i>
                            Komentar</a></li>
                    <li class="nav-item mt-4"><a class="nav-link" href="../logout.php"><i
                                class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                </ul>
                <div class="position-absolute bottom-0 mb-4 w-75">
                    <div class="dark-mode-toggle text-center text-white small" id="darkModeToggle">
                        <i class="fas fa-moon me-1"></i> Dark Mode
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <!-- Welcome Banner -->
                <div class="welcome-banner mb-4 d-flex justify-content-between align-items-center animate-fade">
                    <div>
                        <h2 class="fw-bold mb-1">Halo, <?= htmlspecialchars($username) ?>! 👋</h2>
                        <p class="mb-0 opacity-75">Semangat mengelola blog Anda hari ini.</p>
                    </div>
                    <div class="avatar-large">
                        <?= strtoupper(substr($username, 0, 1)) ?>
                    </div>
                </div>

                <!-- Statistik Cards -->
                <div class="row g-4 mb-5">
                    <div class="col-md-6 col-lg-3 animate-fade" style="animation-delay: 0.1s;">
                        <div class="card stat-card p-3">
                            <div class="stat-icon"><i class="fas fa-file-alt"></i></div>
                            <div class="card-body">
                                <h6 class="text-muted mb-2">Total Artikel</h6>
                                <div class="stat-number"><?= $total_articles ?></div>
                                <small class="text-success mt-2"><i class="fas fa-chart-line"></i> +12%</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3 animate-fade" style="animation-delay: 0.2s;">
                        <div class="card stat-card p-3">
                            <div class="stat-icon"><i class="fas fa-folder"></i></div>
                            <div class="card-body">
                                <h6 class="text-muted mb-2">Kategori</h6>
                                <div class="stat-number"><?= $total_categories ?></div>
                                <small class="text-info"><i class="fas fa-tag"></i> Terorganisir</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3 animate-fade" style="animation-delay: 0.3s;">
                        <div class="card stat-card p-3">
                            <div class="stat-icon"><i class="fas fa-hashtag"></i></div>
                            <div class="card-body">
                                <h6 class="text-muted mb-2">Total Tag</h6>
                                <div class="stat-number"><?= $total_tags ?></div>
                                <small class="text-warning"><i class="fas fa-chart-simple"></i> Populer</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3 animate-fade" style="animation-delay: 0.4s;">
                        <div class="card stat-card p-3">
                            <div class="stat-icon"><i class="fas fa-comment-dots"></i></div>
                            <div class="card-body">
                                <h6 class="text-muted mb-2">Komentar</h6>
                                <div class="stat-number"><?= $total_comments ?></div>
                                <small class="text-primary"><i class="fas fa-users"></i> Interaksi</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Chart Section -->
                <div class="row g-4 mb-5">
                    <div class="col-lg-8 animate-fade" style="animation-delay: 0.5s;">
                        <div class="chart-container">
                            <h5 class="fw-semibold mb-3"><i class="fas fa-chart-line me-2 text-primary"></i> Tren
                                Artikel & Komentar (6 Bulan)</h5>
                            <canvas id="trendChart" height="250"></canvas>
                        </div>
                    </div>
                    <div class="col-lg-4 animate-fade" style="animation-delay: 0.6s;">
                        <div class="chart-container h-100 d-flex flex-column justify-content-center">
                            <h5 class="fw-semibold mb-3"><i class="fas fa-chart-pie me-2 text-success"></i> Komposisi
                                Konten</h5>
                            <canvas id="pieChart" height="200"></canvas>
                            <div class="mt-3 text-center text-muted small">
                                <i class="fas fa-circle text-primary me-1"></i> Artikel &nbsp;&nbsp;
                                <i class="fas fa-circle text-warning me-1"></i> Kategori &nbsp;&nbsp;
                                <i class="fas fa-circle text-info me-1"></i> Tag
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tabel Data Terbaru -->
                <div class="row g-4">
                    <div class="col-lg-6 animate-fade" style="animation-delay: 0.7s;">
                        <div class="chart-container p-0">
                            <div class="p-3 border-bottom">
                                <h5 class="fw-semibold mb-0"><i class="fas fa-clock me-2 text-primary"></i> Artikel
                                    Terbaru</h5>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-custom mb-0">
                                    <thead>
                                        <tr>
                                            <th>Judul</th>
                                            <th>Penulis</th>
                                            <th>Status</th>
                                            <th>Tanggal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_articles as $article): ?>
                                            <tr>
                                                <td><?= htmlspecialchars(substr($article['title'], 0, 30)) ?>...</td>
                                                <td><?= htmlspecialchars($article['author']) ?></td>
                                                <td><span
                                                        class="badge <?= $article['status'] == 'published' ? 'bg-success' : 'bg-secondary' ?>"><?= $article['status'] ?></span>
                                                </td>
                                                <td><?= date('d/m/Y', strtotime($article['created_at'])) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($recent_articles)): ?>
                                            <tr>
                                                <td colspan="4" class="text-center">Belum ada artikel</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 animate-fade" style="animation-delay: 0.8s;">
                        <div class="chart-container p-0">
                            <div class="p-3 border-bottom">
                                <h5 class="fw-semibold mb-0"><i class="fas fa-comment me-2 text-info"></i> Komentar
                                    Terbaru</h5>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-custom mb-0">
                                    <thead>
                                        <tr>
                                            <th>Nama</th>
                                            <th>Komentar</th>
                                            <th>Artikel</th>
                                            <th>Tanggal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_comments as $comment): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($comment['author_name']) ?></td>
                                                <td><?= htmlspecialchars(substr($comment['content'], 0, 40)) ?>...</td>
                                                <td><?= htmlspecialchars(substr($comment['article_title'], 0, 20)) ?></td>
                                                <td><?= date('d/m/Y', strtotime($comment['created_at'])) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($recent_comments)): ?>
                                            <tr>
                                                <td colspan="4" class="text-center">Belum ada komentar</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Chart Tren
        const ctx = document.getElementById('trendChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode($months) ?>,
                datasets: [
                    {
                        label: 'Artikel',
                        data: <?= json_encode($article_counts) ?>,
                        borderColor: '#6366f1',
                        backgroundColor: 'rgba(99,102,241,0.1)',
                        tension: 0.4,
                        fill: true,
                        pointBackgroundColor: '#6366f1'
                    },
                    {
                        label: 'Komentar',
                        data: <?= json_encode($comment_counts) ?>,
                        borderColor: '#8b5cf6',
                        backgroundColor: 'rgba(139,92,246,0.05)',
                        tension: 0.4,
                        fill: true,
                        pointBackgroundColor: '#8b5cf6'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { position: 'top' },
                }
            }
        });

        // Pie Chart
        const pieCtx = document.getElementById('pieChart').getContext('2d');
        new Chart(pieCtx, {
            type: 'doughnut',
            data: {
                labels: ['Artikel', 'Kategori', 'Tag'],
                datasets: [{
                    data: [<?= $total_articles ?>, <?= $total_categories ?>, <?= $total_tags ?>],
                    backgroundColor: ['#6366f1', '#f59e0b', '#06b6d4'],
                    borderWidth: 0,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: { legend: { display: false } }
            }
        });

        // Dark Mode Toggle
        const darkModeToggle = document.getElementById('darkModeToggle');
        darkModeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            const icon = darkModeToggle.querySelector('i');
            if (document.body.classList.contains('dark-mode')) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
                darkModeToggle.innerHTML = '<i class="fas fa-sun me-1"></i> Light Mode';
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
                darkModeToggle.innerHTML = '<i class="fas fa-moon me-1"></i> Dark Mode';
            }
        });
    </script>
</body>

</html>