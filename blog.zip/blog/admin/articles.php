<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Hapus artikel
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    if ($role == 'admin') {
        $stmt = $pdo->prepare("DELETE FROM articles WHERE id = ?");
        $stmt->execute([$id]);
    } else {
        $stmt = $pdo->prepare("DELETE FROM articles WHERE id = ? AND author_id = ?");
        $stmt->execute([$id, $user_id]);
    }
    header('Location: articles.php');
    exit();
}

// Toggle status
if (isset($_GET['toggle_status'])) {
    $id = $_GET['toggle_status'];
    $stmt = $pdo->prepare("SELECT status FROM articles WHERE id = ?");
    $stmt->execute([$id]);
    $current = $stmt->fetch()['status'];
    $new = ($current == 'published') ? 'draft' : 'published';
    if ($role == 'admin') {
        $stmt = $pdo->prepare("UPDATE articles SET status = ? WHERE id = ?");
        $stmt->execute([$new, $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE articles SET status = ? WHERE id = ? AND author_id = ?");
        $stmt->execute([$new, $id, $user_id]);
    }
    header('Location: articles.php');
    exit();
}

// Ambil data artikel
if ($role == 'admin') {
    $stmt = $pdo->query("SELECT a.*, u.username as author_name, c.name as category_name FROM articles a LEFT JOIN users u ON a.author_id = u.id LEFT JOIN categories c ON a.category_id = c.id ORDER BY a.created_at DESC");
} else {
    $stmt = $pdo->prepare("SELECT a.*, u.username as author_name, c.name as category_name FROM articles a LEFT JOIN users u ON a.author_id = u.id LEFT JOIN categories c ON a.category_id = c.id WHERE a.author_id = ? ORDER BY a.created_at DESC");
    $stmt->execute([$user_id]);
}
$articles = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Artikel | BlogCMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: #f0f4f8;
            transition: background 0.3s, color 0.3s;
        }

        body.dark-mode {
            background: #121212;
            color: #e0e0e0;
        }

        body.dark-mode .card,
        body.dark-mode .sidebar {
            background: #1e1e2f;
            color: #e0e0e0;
            border-color: #2d2d44;
        }

        body.dark-mode .table {
            color: #e0e0e0;
        }

        body.dark-mode .table thead th {
            background: #2d2d44;
            color: #fff;
        }

        body.dark-mode .table td {
            background: #1e1e2f;
            color: #ccc;
        }

        body.dark-mode .badge.bg-light {
            background: #2d2d44 !important;
            color: #fff;
        }

        /* Sidebar */
        .sidebar {
            background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
            min-height: 100vh;
            box-shadow: 8px 0 20px rgba(0, 0, 0, 0.2);
            transition: all 0.3s;
        }

        .sidebar .nav-link {
            color: #cbd5e1;
            border-radius: 12px;
            margin: 6px 12px;
            padding: 12px 16px;
            transition: all 0.3s;
            font-weight: 500;
        }

        .sidebar .nav-link i {
            width: 28px;
        }

        .sidebar .nav-link:hover {
            background: rgba(99, 102, 241, 0.2);
            color: white;
            transform: translateX(8px);
        }

        .sidebar .nav-link.active {
            background: linear-gradient(90deg, #6366f1, #8b5cf6);
            color: white;
            box-shadow: 0 5px 15px rgba(99, 102, 241, 0.3);
        }

        /* Card content */
        .content-card {
            border: none;
            border-radius: 28px;
            background: white;
            backdrop-filter: blur(10px);
            box-shadow: 0 15px 35px -10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            overflow: hidden;
        }

        .btn-gradient {
            background: linear-gradient(90deg, #6366f1, #8b5cf6);
            border: none;
            transition: all 0.3s;
            color: white;
        }

        .btn-gradient:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.4);
            color: white;
        }

        .btn-outline-gradient {
            background: transparent;
            border: 1px solid #6366f1;
            color: #6366f1;
            transition: all 0.3s;
        }

        .btn-outline-gradient:hover {
            background: linear-gradient(90deg, #6366f1, #8b5cf6);
            border-color: transparent;
            color: white;
        }

        .table-articles {
            border-radius: 20px;
            overflow: hidden;
        }

        .table-articles thead th {
            background: #f8fafc;
            border-bottom: 2px solid #e2e8f0;
            font-weight: 600;
            padding: 15px;
        }

        .table-articles tbody tr {
            transition: all 0.2s;
        }

        .table-articles tbody tr:hover {
            background: rgba(99, 102, 241, 0.05);
            transform: scale(1.01);
        }

        .badge-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-weight: 500;
        }

        .action-icons a {
            margin: 0 5px;
            transition: all 0.2s;
            display: inline-block;
        }

        .action-icons a:hover {
            transform: scale(1.1);
        }

        .dark-mode-toggle {
            cursor: pointer;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 30px;
            padding: 8px 16px;
            transition: all 0.3s;
        }

        .dark-mode-toggle:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .fade-up {
            animation: fadeUp 0.5s ease forwards;
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .search-box {
            border-radius: 40px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .search-box input {
            border: none;
            padding: 12px 20px;
            background: #f1f5f9;
        }

        .search-box button {
            background: #f1f5f9;
            border: none;
            color: #6366f1;
        }

        body.dark-mode .search-box input,
        body.dark-mode .search-box button {
            background: #2d2d44;
            color: #e0e0e0;
        }
    </style>
</head>

<body>
    <div class="container-fluid p-0">
        <div class="row g-0">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-3">
                <div class="text-center mb-4 pt-3">
                    <i class="fas fa-blog fa-3x text-white"></i>
                    <h4 class="text-white mt-2 fw-bold">BlogCMS</h4>
                    <span class="badge bg-gradient mt-1 px-3 py-1 rounded-pill"
                        style="background: linear-gradient(90deg,#6366f1,#8b5cf6);"><?= ucfirst($role) ?></span>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i
                                class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="articles.php"><i
                                class="fas fa-newspaper me-2"></i> Artikel</a></li>
                    <?php if ($role == 'admin'): ?>
                        <li class="nav-item"><a class="nav-link" href="categories.php"><i class="fas fa-tags me-2"></i>
                                Kategori</a></li>
                        <li class="nav-item"><a class="nav-link" href="tags.php"><i class="fas fa-hashtag me-2"></i> Tag</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item"><a class="nav-link" href="comments.php"><i class="fas fa-comments me-2"></i>
                            Komentar</a></li>
                    <li class="nav-item mt-4"><a class="nav-link" href="../logout.php"><i
                                class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                </ul>
                <div class="position-absolute bottom-0 mb-4 w-75">
                    <div class="dark-mode-toggle text-center text-white small" id="darkModeToggle">
                        <i class="fas fa-moon me-1"></i> Dark Mode
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                    <h2 class="fw-bold mb-0"><i class="fas fa-newspaper me-2 text-primary"></i> Manajemen Artikel</h2>
                    <a href="article_form.php" class="btn btn-gradient px-4 py-2 rounded-pill">
                        <i class="fas fa-plus me-2"></i> Artikel Baru
                    </a>
                </div>

                <!-- Search & Filter (simple) -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="search-box d-flex">
                            <input type="text" id="searchInput" class="form-control"
                                placeholder="Cari judul artikel...">
                            <button class="px-3" onclick="filterTable()"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
                </div>

                <!-- Tabel Artikel dengan Card Futuristik -->
                <div class="card content-card fade-up">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-articles mb-0" id="articlesTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Judul</th>
                                        <th>Kategori</th>
                                        <th>Penulis</th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($articles as $article): ?>
                                        <tr class="article-row">
                                            <td><?= $article['id'] ?></td>
                                            <td> <class="fw-semibold"><?= htmlspecialchars($article['title']) ?></td>
                                            <td>><span
                                                    class="badge bg-light text-dark"><?= htmlspecialchars($article['category_name'] ?? '-') ?></span>
                                            </td>
                                            <td>><?= htmlspecialchars($article['author_name']) ?></td>
                                            <td>
                                                <?php if ($article['status'] == 'published'): ?>
                                                    <span class="badge-status bg-success bg-opacity-10 text-success"><i
                                                            class="fas fa-check-circle me-1"></i> Published</span>
                                                <?php else: ?>
                                                    <span class="badge-status bg-secondary bg-opacity-10 text-secondary"><i
                                                            class="fas fa-pen me-1"></i> Draft</span>
                                                <?php endif; ?>
                                                </span>
                                            </td>
                                            <td>><?= date('d M Y', strtotime($article['created_at'])) ?></td>
                                            <td class="action-icons">
                                                <a href="article_form.php?edit=<?= $article['id'] ?>" class="text-primary"
                                                    title="Edit"><i class="fas fa-edit fa-lg"></i></a>
                                                <a href="articles.php?delete=<?= $article['id'] ?>" class="text-danger"
                                                    onclick="return confirm('Yakin hapus artikel ini?')" title="Hapus"><i
                                                        class="fas fa-trash-alt fa-lg"></i></a>
                                                <a href="articles.php?toggle_status=<?= $article['id'] ?>" class="text-info"
                                                    title="<?= ($article['status'] == 'published') ? 'Unpublish' : 'Publish' ?>"><i
                                                        class="fas fa-toggle-<?= ($article['status'] == 'published') ? 'on fa-flip-horizontal' : 'off' ?> fa-lg"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($articles)): ?>
                                        <tr>
                                            <td colspan="7" class="text-center py-5">Belum ada artikel. <a
                                                    href="article_form.php">Buat sekarang</a></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Info tambahan -->
                <div class="mt-4 text-muted small text-center">
                    <i class="fas fa-info-circle me-1"></i> Total <?= count($articles) ?> artikel ditemukan.
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Dark Mode Toggle
        const darkModeToggle = document.getElementById('darkModeToggle');
        darkModeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            const icon = darkModeToggle.querySelector('i');
            if (document.body.classList.contains('dark-mode')) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
                darkModeToggle.innerHTML = '<i class="fas fa-sun me-1"></i> Light Mode';
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
                darkModeToggle.innerHTML = '<i class="fas fa-moon me-1"></i> Dark Mode';
            }
        });

        // Filter tabel pencarian
        function filterTable() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const rows = document.querySelectorAll('#articlesTable tbody tr');
            rows.forEach(row => {
                const titleCell = row.cells[1];
                if (titleCell) {
                    const titleText = titleCell.textContent.toLowerCase();
                    row.style.display = titleText.includes(filter) ? '' : 'none';
                }
            });
        }
        document.getElementById('searchInput').addEventListener('keyup', filterTable);
    </script>
</body>

</html>