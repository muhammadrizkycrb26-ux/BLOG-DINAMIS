<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

// Tambah tag
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add'])) {
    $name = trim($_POST['name']);
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
    if ($name) {
        $stmt = $pdo->prepare("INSERT INTO tags (name, slug) VALUES (?, ?)");
        $stmt->execute([$name, $slug]);
    }
    header('Location: tags.php');
    exit();
}

// Edit tag
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit'])) {
    $id = $_POST['id'];
    $name = trim($_POST['name']);
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
    $stmt = $pdo->prepare("UPDATE tags SET name = ?, slug = ? WHERE id = ?");
    $stmt->execute([$name, $slug, $id]);
    header('Location: tags.php');
    exit();
}

// Hapus tag
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM tags WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: tags.php');
    exit();
}

$tags = $pdo->query("SELECT * FROM tags ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Manajemen Tag | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: #f0f4f8;
        }

        .sidebar {
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
        }

        .sidebar .nav-link {
            color: #cbd5e1;
            border-radius: 12px;
            margin: 5px 10px;
            transition: all 0.3s;
        }

        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background: rgba(99, 102, 241, 0.2);
            color: white;
        }

        .card-glass {
            background: white;
            border-radius: 28px;
            border: none;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
        }

        .btn-gradient {
            background: linear-gradient(90deg, #6366f1, #8b5cf6);
            border: none;
            color: white;
            border-radius: 40px;
            padding: 8px 20px;
        }

        .btn-gradient:hover {
            background: linear-gradient(90deg, #4f52e0, #7c3aed);
        }

        .table-custom th {
            background: #f8fafc;
            border-bottom: 2px solid #e2e8f0;
        }

        .badge-tag {
            background: #e2e8f0;
            color: #1e293b;
            padding: 5px 12px;
            border-radius: 30px;
            font-weight: 500;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-3">
                <div class="text-center mb-4">
                    <i class="fas fa-blog fa-3x text-white"></i>
                    <h4 class="text-white mt-2">BlogCMS</h4>
                    <span class="badge bg-light text-dark">Admin</span>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i
                                class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="articles.php"><i class="fas fa-newspaper me-2"></i>
                            Artikel</a></li>
                    <li class="nav-item"><a class="nav-link" href="categories.php"><i class="fas fa-tags me-2"></i>
                            Kategori</a></li>
                    <li class="nav-item"><a class="nav-link active" href="tags.php"><i class="fas fa-hashtag me-2"></i>
                            Tag</a></li>
                    <li class="nav-item"><a class="nav-link" href="comments.php"><i class="fas fa-comments me-2"></i>
                            Komentar</a></li>
                    <li class="nav-item mt-4"><a class="nav-link" href="../logout.php"><i
                                class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="fw-bold"><i class="fas fa-hashtag me-2 text-primary"></i> Manajemen Tag</h2>
                    <button class="btn btn-gradient" data-bs-toggle="modal" data-bs-target="#addModal">
                        <i class="fas fa-plus me-2"></i>Tambah Tag
                    </button>
                </div>

                <div class="card-glass p-4">
                    <div class="table-responsive">
                        <table class="table table-custom align-middle">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama Tag</th>
                                    <th>Slug</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($tags as $tag): ?>
                                    <tr>
                                        <td><?= $tag['id'] ?></td>
                                        <td><span class="badge-tag"><i class="fas fa-hashtag me-1"></i>
                                                <?= htmlspecialchars($tag['name']) ?></span></td>
                                        <td><code><?= $tag['slug'] ?></code></td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal"
                                                data-bs-target="#editModal<?= $tag['id'] ?>">
                                                <i class="fas fa-edit"></i> Edit
                                            </button>
                                            <a href="?delete=<?= $tag['id'] ?>" class="btn btn-sm btn-outline-danger"
                                                onclick="return confirm('Yakin hapus tag ini?')">
                                                <i class="fas fa-trash"></i> Hapus
                                            </a>
                                        </td>
                                    </tr>

                                    <!-- Modal Edit -->
                                    <div class="modal fade" id="editModal<?= $tag['id'] ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form method="POST">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Edit Tag</h5>
                                                        <button type="button" class="btn-close"
                                                            data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="id" value="<?= $tag['id'] ?>">
                                                        <div class="mb-3">
                                                            <label>Nama Tag</label>
                                                            <input type="text" name="name" class="form-control"
                                                                value="<?= htmlspecialchars($tag['name']) ?>" required>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Batal</button>
                                                        <button type="submit" name="edit"
                                                            class="btn btn-primary">Simpan</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                                <?php if (empty($tags)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">Belum ada tag. Silakan tambah.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Tambah -->
    <div class="modal fade" id="addModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Tag Baru</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label>Nama Tag</label>
                            <input type="text" name="name" class="form-control" placeholder="Contoh: Laravel" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="add" class="btn btn-gradient">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>